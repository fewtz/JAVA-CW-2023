package edu.uob.Utilities;

public enum valueType {
        INTEGER,
        FLOAT,
        BOOLEAN,
        STRING,
}
